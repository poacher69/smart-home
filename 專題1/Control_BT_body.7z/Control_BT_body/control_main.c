/**   Project name : 
*   
--------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>

#include "stm32f0xx.h"          // File name depends on device used
#include "RTE_Components.h"      // Component selection 

void Car_Direction(uint32_t);
extern void stdout_init (void);
extern void melody_main (void);								// from molody_main.c
extern void PlayMelody(uint8_t song_num);		// from molody_main.c
extern volatile uint32_t button_Pressed;
//extern volatile uint32_t buttonStatus;
void TestTempuature(char);

#define Melody_stop					0
#define Melody_sea_laugh		1									// same as molody_main.c, duplicate define is O.K.
#define Melody_happy_song		2									// same as molody_main.c
#define Melody_little_star	3									// same as molody_main.c
#define Melody_little_bee		4									// same as molody_main.c
volatile uint8_t current_song_num, melody_stop_flag;


volatile uint32_t msTicks;         // Counter for millisecond Interval
volatile uint8_t send,String_length,Tx_complete;
volatile char BT_receive_cmd;

//body part
volatile uint8_t send_Body, CMD_length, Tx_Body_complete;

uint8_t ATCMD1[3] = {0xA5, 0x15, 0xBA};

#define buffer_max 9
volatile uint8_t receive_buffer[buffer_max];
volatile uint8_t receive_ptr, Rx_Body_complete;

char bodyValueString[3];
char bodyString[] = "\n\r Your body temperature is ";
char bodyError[] = "\n\r Body detection error.\n\r";

//temp part
char tempValuesString[3];
char humValuesString[3];
//char tempString[]="\n\rThe current tempuature is: ";
//char humString[]="\n\rThe current humidity is: ";
char tempString[]="T";
char humString[]="H";
char parityError[]="\n\rParity check error.\n\r";

char string1[]="Touch key 1 is Pressed. \n\r";
char string2[]="Touch key 2 is Pressed. \n\r";
char string3[]="Touch key 3 is Pressed. \n\r";
char string4[]="Touch key 4 is Pressed. \n\r";

#define NUM_KEYS  1                     /* Number of available keys           */

// for car control
#define Car_Stop_CMD				'p'
#define Car_Forward_CMD			'f'
#define Car_Left_CMD				'l'
#define Car_Right_CMD				'r'
#define Car_Backward_CMD		'b'

#define Direction_Stop			0
#define Direction_Forward		1
#define Direction_Left			2
#define Direction_Right			3
#define Direction_Backward	4

#define Drive_Stop			0x0ul
#define Drive_Forward		0x6ul
#define Drive_Left			0x4ul
#define Drive_Right			0x2ul
#define Drive_Backward	0x9ul

/* Keys for NUCLEO Board */
#define USER_1  1
#define USER_2  2
#define USER_3	3
#define USER_4  4
#define USER_default  10
#define Button_Send_CMD	's'

/* Keys for NUCLEO Board */
#define USER    1
#define END_CMD		'e'

#define Lamp1_ON	'x'
#define Lamp1_OFF	'y'
#define Lamp2_ON	'c'
#define Lamp2_OFF	'd'
#define Fan1_ON		'h'
#define Fan1_OFF	'i'
#define Fan2_ON		'j'
#define Fan2_OFF	'k'

#define Song_OFF_CMD	'0'
#define Song_1_CMD		'1'
#define Song_2_CMD		'2'
#define Song_3_CMD		'3'
#define Song_4_CMD		'4'

/*--------------------------------------------------------------------------------*/
// SysTick Interrupt Handler
/*--------------------------------------------------------------------------------*/
void SysTick_Handler (void) 
{       
    msTicks++;           // Increment Counter
}

/*--------------------------------------------------------------------------------*/
// Delay: delay a number of Systicks
/*--------------------------------------------------------------------------------*/
void Delay(uint32_t dlyTicks){
	uint32_t currentTicks;
	
	currentTicks = msTicks;
	while( (msTicks - currentTicks) < dlyTicks ){
		  __NOP();
	}
}

/**-----------------------------------------------------------------------------
  * @brief  Configures the System clock frequency, AHB/APBx prescalers and Flash
  *         settings.
  * @note   This function should be called only once the RCC clock configuration
  *         is reset to the default reset state (done in SystemInit() function).
  * @param  None
  * @retval None
--------------------------------------------------------------------------------  */
static void SetSysClock(void)
{
	SystemCoreClock = 48000000;
  /* SYSCLK, HCLK, PCLK configuration ----------------------------------------*/

  /* At this stage the HSI is already enabled */

  /* Enable Prefetch Buffer and set Flash Latency */
  FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;
 
  /* HCLK = SYSCLK */
  RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;
      
  /* PCLK = HCLK */
  RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE_DIV1;

  /* PLL configuration = (HSI/2) * 12 = ~48 MHz */
  RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_PLLSRC | RCC_CFGR_PLLMUL));
  RCC->CFGR |= (uint32_t)(RCC_CFGR_PLLSRC_HSI_DIV2 | RCC_CFGR_PLLMUL12);
            
  /* Enable PLL */
  RCC->CR |= RCC_CR_PLLON;

  /* Wait till PLL is ready */
  while((RCC->CR & RCC_CR_PLLRDY) == 0)
  {
  }

  /* Select PLL as system clock source */
  RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
  RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;    

  /* Wait till PLL is used as system clock source */
  while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)RCC_CFGR_SWS_PLL)
  {
  }
}
		
//-----------------------------------
void colorLED_ON(int colorNum)
{
	int colorArray[10] = { 0, 1,2 ,3,4,5,6,7};
	uint32_t  LEDValue;
	
	   LEDValue = colorArray[colorNum];
	   GPIOA->ODR &=  ~(0x7ul << 6);
	   GPIOA->ODR |= LEDValue<<6 ;
	
}


/*--------------------------------------------------------------------------------*/
// Button_Init(void)        ;Initialize button
// PC.13 to control User botton, set PC.13 is input pin 
/*--------------------------------------------------------------------------------*/
void Button_Init(void) {

  RCC->AHBENR |=  (1ul << 19);                  // Enable GPIOC clock       
  GPIOC->MODER &= ~(3ul << 2*13);               // Set PC.13 is input  
   
}

/*------------------------------------------------------------------------------*/
//uint32_t Button_GetState(void)
// Get USER button (PC.13) state
// return: 1 means USER key pressed
/*------------------------------------------------------------------------------*/
uint32_t Button_GetState (void) {

  uint32_t val = 0;

  if ((GPIOC->IDR & (1ul << 13)) == 0) {         //When USER button pressed PC.13=0
    val |= USER;                                 // set USER button pressed
  }
  return (val);

}

//2018-11-13------------------------------------------------------
//confing usart 1, PA9, PA10

void Config_GPIO_USART1(void){
	
	RCC->AHBENR |= 0x1ul << 17;
	
	GPIOA->MODER &= ~(0x3ul<<9*2 | 0x3ul<<10*2);
	GPIOA->MODER |= (0X2ul<<9*2 | 0X2ul<<10*2);
	
	GPIOA->AFR[1] &= ~(0xful<<1*4 | 0xful<<2*4);
	GPIOA->AFR[1] |= (0x1ul<<1*4 | 0x1ul<<2*4);
	
}

//2018-11-13--------------------

void Config_USART1(void){
	RCC->APB2ENR |= 0x1ul <<14;
	USART1->BRR = 48000000 / 115200;
	USART1->CR3 |= 0x1ul<<12;
	USART1->CR1 |= 0x1ul<<5 | 0x1ul<<2 |0x1ul;
	USART1->ICR |= 0x1ul<<6;
	USART1->CR1 |= 0x1ul<<6 | 0x1ul<<3;

  NVIC_ClearPendingIRQ(USART1_IRQn);
  NVIC_SetPriority(USART1_IRQn,3);
  NVIC_EnableIRQ(USART1_IRQn);
}


//----------------------------
// usart 1 handler
//----------------------------
void USART1_IRQHandler(void){

  uint8_t chartoreceive;

  if((USART1->ISR & USART_ISR_TC) == USART_ISR_TC){
    USART1->ICR |= USART_ICR_TCCF;
    if(send == String_length){
      Tx_complete = 1;
    }
  }

  if((USART1->ISR & USART_ISR_RXNE)==USART_ISR_RXNE){
    chartoreceive = (uint8_t)USART1->RDR;
    USART2->TDR = chartoreceive;
		
		switch(chartoreceive){
			case Lamp1_ON:
			case 'X':	
				BT_receive_cmd = Lamp1_ON;
				//colorLED_ON(1);	
				TestTempuature(Lamp1_ON);
				Delay(1500);
				break;
			case Lamp1_OFF:
			case 'Y':	
				BT_receive_cmd = Lamp1_OFF;
				//colorLED_ON(7);
				TestTempuature(Lamp1_OFF);			
				break;
			case Lamp2_ON:
			case 'C':	
				BT_receive_cmd = Lamp2_ON;
				colorLED_ON(2);
				break;
			case Lamp2_OFF:
			case 'D':	
				BT_receive_cmd = Lamp2_OFF;
				colorLED_ON(7);				
				break;
			case Fan1_ON:
			case 'H':	
				BT_receive_cmd = Fan1_ON;
				colorLED_ON(4);	
				break;
			case Fan1_OFF:
			case 'I':	
				BT_receive_cmd = Fan1_OFF;
				colorLED_ON(7);				
				break;
			case Fan2_ON:
			case 'J':	
				BT_receive_cmd = Fan2_ON;
				colorLED_ON(0);
				break;
			case Fan2_OFF:
			case 'K':	
				BT_receive_cmd = Fan2_OFF;
				colorLED_ON(7);													// short-time action, execute immediately				
				break;
			case Song_OFF_CMD:
				BT_receive_cmd = Song_OFF_CMD;
				melody_stop_flag = Melody_stop;					
				break;
			case Song_1_CMD:
				BT_receive_cmd = Song_1_CMD;
				current_song_num = Melody_sea_laugh;		// long-time action, set flag/variable only
				break;
			case Song_2_CMD:
				BT_receive_cmd = Song_2_CMD;
				current_song_num = Melody_happy_song;
				break;
			case Song_3_CMD:
				BT_receive_cmd = Song_3_CMD;
				current_song_num = Melody_little_star;
				break;
			case Song_4_CMD:
				BT_receive_cmd = Song_4_CMD;
				current_song_num = Melody_little_bee;
				break;
							
			case Car_Forward_CMD:
			case 'F':
				BT_receive_cmd = Car_Forward_CMD;
				Car_Direction(Direction_Forward);
				break;
			case Car_Left_CMD:
			case 'L':
				BT_receive_cmd = Car_Left_CMD;
				Car_Direction(Direction_Left);
				Delay(1000);
				Car_Direction(Direction_Forward);
				break;
			case Car_Right_CMD:
			case 'R':
				BT_receive_cmd = Car_Right_CMD;
				Car_Direction(Direction_Right);
				Delay(1000);
				Car_Direction(Direction_Forward);
				break;
			case Car_Backward_CMD:
			case 'B':
				BT_receive_cmd = Car_Backward_CMD;
				Car_Direction(Direction_Backward);
				break;
			case Car_Stop_CMD:
			case 'P':
				BT_receive_cmd = Car_Stop_CMD;
				Car_Direction(Direction_Stop);
				break;				
		}		
  }
}

//body----------------------
void Config_GPIO_PB1011(void)
{
	RCC->AHBENR |= 0x1uL << 18;
	
	GPIOB->MODER &= ~( 0x3uL << 10*2 | 0x3uL << 11*2 );
	GPIOB->MODER |= 0x2uL << 10*2 | 0x2uL << 11*2 ;
	
	GPIOB->AFR[1] &= ~ ( 0xfuL << 2*4 | 0xfuL <<3*4);
	GPIOB->AFR[1] |= ( 0x4uL << 2*4 | 0x4ul << 3*4);
}

//body----------------------
void Config_UART3(void)
{
	
	RCC->APB1ENR |= 0x1uL << 18;
	USART3->BRR = 48000000/115200;
	
	USART3 -> CR3 |= 0x1uL << 12;
	
	USART3-> CR1 |= 0x1uL << 5 | 0x1uL <<2 | 0x1uL;
	USART3-> ICR |= 0x1uL << 6;											//clear TC Flag
	
	USART3 -> CR1 |= 0x1uL << 6 | 0x1uL << 3;
	
	NVIC_ClearPendingIRQ(USART3_4_IRQn);
	NVIC_SetPriority(USART3_4_IRQn,3);
	NVIC_EnableIRQ(USART3_4_IRQn);
}	

//Body--------------------------------
void USART3_4_IRQHandler(void)
{	
	uint8_t chartoreceive;
	
// send AT Command {0xA5, 0x15, 0xBA}	
	if( (USART3->ISR & USART_ISR_TC) == USART_ISR_TC)
	{
		USART3->ICR |= USART_ICR_TCCF;
		if( send == CMD_length )
			Tx_Body_complete = 1;

  }		

	if (  (USART3->ISR & USART_ISR_RXNE) == USART_ISR_RXNE)
	{
		chartoreceive = (uint8_t) USART3->RDR;
//		USART2->TDR = chartoreceive;
		receive_buffer[receive_ptr] = chartoreceive;
		receive_ptr++;
		if (receive_ptr >= buffer_max)
		{
			receive_ptr=0;
			Rx_Body_complete = 1;
			
		}	
	}
	
}	
//Body----------------------
void Send_ATCMD(uint8_t * ATCMD_ptr)
{
	
	  Tx_Body_complete = 0;
		send = 0;
	  CMD_length = 3;
	
	  do {
			
			 if(send == CMD_length) 
			 {	 
				 
				 Tx_Body_complete = 1;
				 
			 } else if(USART3-> ISR & USART_ISR_TXE) {
				 USART3->TDR = *(ATCMD_ptr ++);
				 send++;
				 
			 }	 
			
		} while(Tx_Body_complete == 0);
	
}	
	
	

//Temp&Body-------------------------
void Send_String(char * String_ptr){
  Tx_complete=0;
  send=0;
  String_length=strlen(String_ptr);

  do{
    if(send==String_length){
      Tx_complete=1;
    }
    else if(USART1->ISR & USART_ISR_TXE){
      USART1->TDR = *(String_ptr ++);
      send++;
    }
  }while(Tx_complete==0);
}

//-----------------------------------------
void Color_GPIOA_init(void)
{
	
	RCC->AHBENR |= 0x1ul << 17 ;            // enable clock
	
	GPIOA->MODER &= ~ ( (0x3ul << 6*2) | (0x3ul << 7*2) | (0x3ul << 8*2) );
	GPIOA->MODER |= 0x1ul << 6*2 | 0x1ul << 7*2 | 0x1ul << 8*2 ;        // set PA6,7,8 as output
	
	GPIOA->OSPEEDR &= ~ ( (0x3ul << 6*2) | (0x3ul << 7*2) | (0x3ul << 8*2) );
	GPIOA->OSPEEDR |= 0x1ul << 6*2 | 0x1ul << 7*2 | 0x1ul << 8*2 ;   // set speed as medium	
	
}

/*--------------------------------------------------------------------------------*/
// Init PORTC
/*--------------------------------------------------------------------------------*/
void GPIOC_Init_Car(void)  // PC[3:0]
{
	RCC->AHBENR |= 0x1ul << 19;
	
	GPIOC->MODER &= ~0xfful;
	GPIOC->MODER |= 0x55ul;
	
	GPIOC->OSPEEDR &= ~0xfful;
	GPIOC->OSPEEDR |= 0x55ul;
	
}	

/*--------------------------------------------------------------------------------*/
// Test car direction
/*--------------------------------------------------------------------------------*/
void Car_Direction(uint32_t dirCMD)
{
	switch(dirCMD)
	{
		case Direction_Stop:
			GPIOC->ODR |= 0xful;
			break;
		case Direction_Forward:
			GPIOC->ODR &= ~0xful;
			GPIOC->ODR |= Drive_Forward;			//define Drive_Forward		6
			break;
		case Direction_Left:
			GPIOC->ODR &= ~0xful;
			GPIOC->ODR |= Drive_Left;					//define Drive_Left				4
			break;
		case Direction_Right:
			GPIOC->ODR &= ~0xful;
			GPIOC->ODR |= Drive_Right;				//define Drive_Right			2
			break;
		case Direction_Backward:
			GPIOC->ODR &= ~0xful;
			GPIOC->ODR |= Drive_Backward;			//define Drive_Backward		9
			break;
		default:
			break;
	}
}

/*--------------------------------------------------------------------------------*/
// PA.4 setup
/*--------------------------------------------------------------------------------*/

void setPA4(void)
{
	RCC->AHBENR |= 01ul<<17;
	
	GPIOA->MODER &= ~(0x3ul << 4*2);
	GPIOA->MODER |= 0x1ul << 4*2;			//output
	
	GPIOA->OSPEEDR &= ~(0x3ul << 4*2);
	GPIOA->OSPEEDR |= 0x1ul << 4*2;
}	


/*--------------------------------------------------------------------------------*/
// HT-22 
/*--------------------------------------------------------------------------------*/
void TestTempuature(char tempOrHumiFlag)
{
		int i;
		uint32_t data[43];
		uint32_t pulseWidth, startTick, dataValue, parityCheck, tempData, tempParity;
		uint32_t temperatureValue, humidityValue;
	
		GPIOA->MODER |= 0x1ul << 4*2;			//output
		GPIOA->ODR |= 0x1ul << 4;					//PA.4 output High
		Delay(5);													//5ms
		GPIOA->ODR &= ~(0x1ul << 4);			//PA.4 output Low
		Delay(5);													//5ms
		GPIOA->ODR |= 0x1ul << 4;					//PA.4 output High
		
		GPIOA->MODER &= ~(0x3ul << 4*2);	//input
		startTick = msTicks;
		
		for(i=0;i<42;i++)									//to read 42 bits
		{
			pulseWidth=0;
			
			while((GPIOA->IDR & (0x1ul << 4)) == 0) { //check low
				pulseWidth++;
				if(msTicks - startTick > 500){
					break;
				}	//if check low
			}	//while check low	
				
			while((GPIOA->IDR & (0x1ul << 4)) == (0x1ul <<4)) { //check high	
				pulseWidth++;
				if(msTicks - startTick > 500){
					break;
				}	//if check high				
			}	//while check high
			data[i] = pulseWidth;
		}//inner for
		
//		for(i=0;i<42;i++)									//to write 42 bits' PW
//			printf("PW of received bit %2d = %4d\n\r", i, data[i]);
		
		dataValue = 0;
		parityCheck = 0;
		
		for(i=2;i<42;i++)									//deal with last 40bits
		{
			
			if(i<34){												//data bits
				if(data[i] >190){
					dataValue |= 0x1ul;
				}
				
				if(i<33)
					dataValue = dataValue<<1;
			}	else {												//parity bits
				if(data[i] >190){
					parityCheck |= 0x1ul;
				}
				
				if(i<41)
					parityCheck = parityCheck<<1;
			}	
			
		} // for() deal with last 40bits
		
		printf("data value = %x\n\r", dataValue);
		printf("parity check = %x\n\r", parityCheck);
		tempParity = 0;
		tempData = dataValue;
		for(i=0;i<4;i++)
		{
			tempParity += (tempData & 0xfful);
			tempData = tempData >> 8;
		}	
		
		if((tempParity & 0xfful) == parityCheck)
		{
			temperatureValue = (dataValue & 0xfffful)/10;
			humidityValue = ((dataValue >>16) & 0xfffful)/10;
			
			printf("temperature Value = %d\n\r", temperatureValue);
			printf("humidity Value = %d percent\n\r", humidityValue);
			sprintf(tempValuesString, "%d", temperatureValue);
			sprintf(humValuesString, "%d", humidityValue);
			
			if (tempOrHumiFlag == Lamp1_ON)
			//Send_String((char*) tempString);
			Send_String((char*) tempValuesString);
			//Send_String((char*) humString);
			else
			Send_String((char*) humValuesString);
		}
		else
		{	
			printf("parity check error.\n\r");
			Send_String((char*) parityError);
		}	


/*		
		printf("%s", tempString);
		printf("%s", tempValuesString);
		printf("%s", humString);
		printf("%s", humValuesString);	
*/		
}	

/*--------------------------------------------------------------------------------*/
// BodyTemperature 
/*--------------------------------------------------------------------------------*/
void BodyTemperature(void)
{
	uint8_t paritySum;
	uint16_t bodyValue, enviroValue;
	uint32_t startTick;

	receive_ptr = 0;
	Rx_Body_complete = 0;
	startTick = msTicks;
	
	Send_ATCMD( (uint8_t *)ATCMD1);

	while( Rx_Body_complete == 0)
	{
		if((msTicks - startTick) > 500){
			Rx_Body_complete = 1;
		}	
	}	
	
	if(receive_buffer[0] == 0x5A && receive_buffer[1] == 0x5A)
	{
		if(receive_buffer[2] == 0x45 && receive_buffer[3] == 0x4)
		{
			paritySum=0;
			for(int i=0; i<8; i++)
			{
				paritySum += receive_buffer[i];
			}
			printf("received_buffer = %s", bodyString);
			
			if(paritySum == receive_buffer[8])
			{
				bodyValue = receive_buffer[4] << 8 | receive_buffer[5];
				enviroValue = receive_buffer[6] << 8 | receive_buffer[7];
				bodyValue = bodyValue/100;
				enviroValue = enviroValue/100;
				
				sprintf(bodyValueString, "%d", bodyValue);
				printf("%s", bodyString);
				printf("%s", bodyValueString);
				Send_String((char*) bodyString);
				Send_String((char*) bodyValueString);
				//printf("The body temperature value is %d \n\r", bodyValue);
				//printf("The environment temperature value is %d \n\r", enviroValue);
			}else{
				printf("%s", bodyError);
				Send_String((char*) bodyError);
				//printf("Parity error. \n\r");
			}
		
		}else{
			printf("%s", bodyError);
			Send_String((char*) bodyError);
			//printf("data error. \n\r");
		}
	}else{
		printf("%s", bodyError);
		Send_String((char*) bodyError);
		//printf("data error. \n\r");
	}
}	

/*--------------------------------------------------------------------------------*/
// The processor clock is initialized by CMSIS startup + system file
/*--------------------------------------------------------------------------------*/
int main (void) {        // User application starts here
	
		/* Configure the System clock frequency, AHB/APBx prescalers and Flash settings */
  SetSysClock();
	
	stdout_init();              // Initialize USART 2(PA3 to USART2_RX,PA2 to USART2_TX)  
		                                            
	SysTick_Config(SystemCoreClock/1000);      // System Tick Initializes,set SysTick 1ms interrupt

  NVIC_SetPriority(SysTick_IRQn,1);

  Button_Init();

//BlueTooth: USART1 pair, PA9, PA10
  Config_GPIO_USART1();
  Config_USART1();
	
//environment temperature and humidity: data i/O pin, PA4
	setPA4();
	
//body temperature: USART3 pair, PB10, PB11 	
	Config_GPIO_PB1011();
	Config_UART3();
	
//colorLED: PA6, PA7, PA8 for RGB
	Color_GPIOA_init();
	
//car direction: PC[3:0] for 2 motors	
	GPIOC_Init_Car();
	
	melody_main();
	BT_receive_cmd = END_CMD;
	current_song_num = Melody_stop;
	
	printf("Ready to receive BT. \r\n");
/*	
	printf("Send data to BT. \r\n");
	
	while (Button_GetState()==0);
	
	Send_String((char *)string1);
  Delay(1000);

  printf("Press Blue button. \r\n");
  
  while (Button_GetState()==0);

  Send_String((char *)string2);
  Delay(1000);
*/	


  for(;;)
	{
		switch(BT_receive_cmd)
		{
			case Song_1_CMD:
				PlayMelody(Melody_sea_laugh);
				//TestTempuature();
				//Delay(1500);
				break;
			case Song_2_CMD:
				PlayMelody(Melody_happy_song);
				break;			
			case Song_3_CMD:
				PlayMelody(Melody_little_star);
				break;
			case Song_4_CMD:
				PlayMelody(Melody_little_bee);
				break;
			case Song_OFF_CMD:
			case END_CMD:
				Delay(1000);
				break;
			case Button_Send_CMD:
				if(button_Pressed == USER_1){
					TestTempuature(Lamp1_ON);
					TestTempuature(Lamp1_OFF);				
					//Send_String((char*) string1);
				}else if(button_Pressed == USER_2){
					BodyTemperature();
					//Send_String((char*) string2);
				}else if(button_Pressed == USER_3){
					Send_String((char*) string3);
				}else if(button_Pressed == USER_4){
					Send_String((char*) string4);
				}
				
				BT_receive_cmd = END_CMD;
				break;

		}
		
	}

	
}
