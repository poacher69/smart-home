/**   Project name : 
*   
--------------------------------------------------------------------------------------*/

#include <stdio.h>

#include "stm32f0xx.h"          // File name depends on device used
#include "RTE_Components.h"      // Component selection 

extern void stdout_init (void);
extern volatile uint8_t current_song_num, melody_stop_flag;  //variable defined in control_main
extern volatile char BT_receive_cmd;

//volatile uint32_t msTicks;         // Counter for millisecond Interval

volatile uint32_t TIM2_Ticks;         // Counter for millisecond Interval
//volatile uint32_t buttonStatus;
volatile uint32_t button_Pressed;

#define NUM_KEYS  1                     /* Number of available keys           */

/* Keys for NUCLEO Board */
#define USER    1
#define USER_1  1
#define USER_2  2
#define USER_3	3
#define USER_4  4
#define USER_default  10
#define Button_Send_CMD	's'

/*--------------------------------------------------------------------------------*/
// Delay: delay a number of Systicks
/*--------------------------------------------------------------------------------*/
void ConfigTimer2(void)
{
	RCC->APB1ENR |= 0x1ul;
	
	TIM2->PSC=479;
	TIM2->ARR=99;					// (1/48000000)*480*100 = 1/1000 sec = 0.1 msec
	TIM2->CNT=0;
	TIM2->CR1 |= 0x1ul;
	TIM2->DIER |= 0x1ul;

	NVIC_ClearPendingIRQ(TIM2_IRQn);
	NVIC_SetPriority(TIM2_IRQn, 0);
	NVIC_EnableIRQ(TIM2_IRQn);
}

/*--------------------------------------------------------------------------------*/
// Delay: delay a number of Systicks
/*--------------------------------------------------------------------------------*/
void TIM2_IRQHandler(void)
{
	TIM2_Ticks++;
	TIM2->SR &= ~0x1ul;
}

/*--------------------------------------------------------------------------------*/
// Delay: delay a number of Systicks
/*--------------------------------------------------------------------------------*/
void TIM2Delay(uint32_t dlyTicks){
	uint32_t currentTicks;
	
	currentTicks = TIM2_Ticks;
	while( (TIM2_Ticks - currentTicks) < dlyTicks ){
		  __NOP();
	}
}


void ConfigEXTIPA01(void){
	
	RCC->AHBENR |= 0x1ul <<17;
	GPIOA->MODER &= ~ (0x3ul | 0x3ul << 1*2);   // set as input
	
	RCC->APB2ENR |= 0x1ul;      // enable SYSCFG clock
	
	SYSCFG->EXTICR[0] &= ~ ( 0xful | 0xful << 1*4);   // select PA.0,1 as int
	
	EXTI->IMR |= (0x1ul | 0x1ul << 1);       // disable mask
	EXTI->RTSR |= (0x1ul | 0x1ul << 1);        // set rising edge trigger
	
	EXTI->PR |= (0x1ul | 0x1ul << 1);        // clean pending register
	
	NVIC_ClearPendingIRQ(EXTI0_1_IRQn);
	NVIC_SetPriority(EXTI0_1_IRQn, 0);
	NVIC_EnableIRQ(EXTI0_1_IRQn);
	
}


//---------------------------------
void EXTI0_1_IRQHandler(void){
	
	uint32_t PR_value;
	
	PR_value = EXTI->PR;
	
	if( PR_value & 0x1ul){
		if((GPIOA->IDR & 0x1ul ) == 1){
			button_Pressed = USER_1;
			BT_receive_cmd = Button_Send_CMD;
			
			printf("PA.0 was pressed.\n\r");
			 
		}
		
		EXTI->PR |= 0x1ul;
	}
	
	if((PR_value & 0x2ul) == 0x2ul){
		 if( (GPIOA->IDR & 0x2ul) == 0x2ul ){
				button_Pressed = USER_2;
				BT_receive_cmd = Button_Send_CMD;
				printf("PA.1 was pressed.\n\r");
		 }
		 
		 EXTI->PR |= (0x1ul << 1);
		
	}
}


/*------------------------------------------------------------------------------*/
// setup PB.3 and PB.5

void Config_PB3PB5(void)
{
		RCC->AHBENR |= 0x1ul << 18;										// enable PORTB clock

		GPIOB->MODER &= ~(0x3ul<< 2*3|0x3ul << 2*5);	// PB.3 and PB.5 set as input
		
		RCC->APB2ENR |= 0x1ul;
	
		//SYSCFG -> EXTICR[0] &= ~(0xful << 4*3);		// unselect PB.3
	  SYSCFG -> EXTICR[0] |= 0x1ul << 4*3;			// select PB.3; SYSCFG -> EXTICR[0]:15~12 to MUX

		SYSCFG -> EXTICR[1] &= ~(0xful << 4*1);		// unselect PB.5
	  SYSCFG -> EXTICR[1] |= 0x1ul << 4*1;			// select PB.5; SYSCFG -> EXTICR[1]:7~4 to MUX
// EXTI Setting (Interrupt Mask, 1=true=Mask)
		EXTI ->IMR |= (0x1ul <<3 | 0x1ul <<5);							//DISABLE(1) mask
//EXTI ->FTSR |= (0x1ul <<3 | 0x1ul <<5);							//Falling Trigger
		EXTI ->RTSR |= (0x1ul <<3 | 0x1ul <<5);							//Rising Trigger
		
		EXTI ->PR |= (0x1ul<<3 | 0x1ul <<5);								//clean(1) pending register

// NVIC Setting, PB.3 
		NVIC_ClearPendingIRQ(EXTI2_3_IRQn);
		NVIC_SetPriority(EXTI2_3_IRQn, 3);
		NVIC_EnableIRQ(EXTI2_3_IRQn);										// NVIC actually enables interrupt

// NVIC Setting, PB.5 	
		NVIC_ClearPendingIRQ(EXTI4_15_IRQn);
		NVIC_SetPriority(EXTI4_15_IRQn, 3);
		NVIC_EnableIRQ(EXTI4_15_IRQn);										// NVIC actually enables interrupt
}	

/*------------------------------------------------------------------------------*/

void EXTI2_3_IRQHandler(void)
{
		uint32_t PR_value;
	
		PR_value = EXTI->PR;
	
		if(PR_value & 0x1ul << 3)
		{
			if((GPIOB->IDR & 0x1ul << 3))			//PB.3 Released 
			{
				button_Pressed = USER_3;
				BT_receive_cmd = Button_Send_CMD;
				printf("PB.3 was pressed\n\r");
			}
			
			EXTI->PR |= 0x1ul << 3;								//clean(1) pending register
		}
}

/*------------------------------------------------------------------------------*/

void EXTI4_15_IRQHandler(void)
{
		uint32_t PR_value;
	
		PR_value = EXTI->PR;
	
		if(PR_value & 0x1ul << 5)
		{
			if((GPIOB->IDR & 0x1ul << 5))			//PB.5 Released 
			{
				button_Pressed = USER_4;
				BT_receive_cmd = Button_Send_CMD;
				printf("PB.5 was pressed\n\r");
			}
			
			EXTI->PR |= 0x1ul << 5;								//clean(1) pending register
		}
}


/*--------------------------------------------------------------------------------*/
// Config PB4 for Timer3 PWM
/*--------------------------------------------------------------------------------*/
void Config_PB4_TIM3_PWM(void)
{
		RCC->AHBENR |= 0x1ul << 18;
		GPIOB->MODER &= ~(0x3ul << 2*4);		// PB.4
	  GPIOB->MODER |= 0x2ul << 2*4;
		GPIOB->AFR[0] |= 0x1ul << 4*4;			// AF1; TIM3_CH1
	
		RCC->APB1ENR |= 0x1ul << 1*1;
		
		TIM3->PSC = 479;										// for melody tone
		TIM3->ARR = 99;
		TIM3->CCR1 = 50;
		TIM3->CNT = 0;
	
		TIM3->CCMR1 |= 0x6ul << 4;			// Enable PWM
		TIM3->CR1 |= 0x1ul | 0x1ul << 7;							// enable timer 3
	
}	

/*--------------------------------------------------------------------------------*/
// Enable Timer3 PWM
/*--------------------------------------------------------------------------------*/
void EnablePWM(void)
{
		//TIM3->CNT = 0;								// commented in melody application
		TIM3->CR1 |= 0x1ul;							// enable timer 3
		TIM3->CCER |= 0x1ul;						// enable PWM output
}


/*--------------------------------------------------------------------------------*/
// Disable Timer3 PWM
/*--------------------------------------------------------------------------------*/
void DisablePWM(void)
{
		TIM3->CCER &= ~0x1ul;						// close PWM output
		TIM3->CR1 &= ~0x1ul;						// enable timer 3
}

/*--------------------------------------------------------------------------------*/
// Change Timer3 PWM
/*--------------------------------------------------------------------------------*/
void ChangePWMLevel(uint32_t highWidth)
{
		TIM3->CCR1 = 	highWidth;				// close PWM output
		TIM3->CNT = 0;									// enable timer 3
}

/*--------------------------------------------------------------------------------*/
// select tone
/*--------------------------------------------------------------------------------*/
void SelectTone(uint32_t tone_num)
{
	uint32_t ARR_value;
	// program ARR register
	uint32_t ToneArr[]={0,764,681,607,573,510,454,405,382,340,303,286,255,227,202,191,170,152,143,128,114,101};
	// 1/((1/48*10^6)*480*764 (sec)) = (48*10^6)/(480*764)(Hz)=100000/764=131(Hz)
	// 480=Pre-scale value, 764 = ARR value
	// set ARR value to produce Tone pulses to synthesize corresponding frequency 

	ARR_value = ToneArr[tone_num];
	TIM3->CNT=0;
	TIM3->ARR=ARR_value;
	TIM3->CCR1=ARR_value/2;
		
}

/*--------------------------------------------------------------------------------*/
// play melody
/*--------------------------------------------------------------------------------*/
#define beatTime 						100
#define Melody_sea_laugh		1
#define Melody_happy_song		2
#define Melody_little_star	3
#define Melody_little_bee		4

void PlayMelody(uint8_t song_num)
{
	//Basic tone
  uint8_t note_basic[]={1,2,3,4,5,6,7,1+7,2+7,3+7,4+7,5+7,6+7,7+7,1+14,2+14,3+14,4+14,5+14,6+14,7+14}; 
	// Happy Birthday Song
	uint8_t note_happy_song[]={5,5,6,5,1+7,7,5,5,6,5,2+7,1+7,5,5,5+7,3+7,1+7,7,6,4+7,4+7,3+7,1+7,2+7,1+7 };
	uint16_t beat_happy_song[]={250,250,500,500,500,1000,250,250,500,500,500,1000,250,250,500,500,500,500,1500,250,250,500,500,500,1500};
	// Little Star Song	
	uint8_t note_little_star[]={1,1,5,5,6,6,5,4,4,3,3,2,2,1,5,5,4,4,3,3,2,5,5,4,4,3,3,2,1,1,5,5,6,6,5,4,4,3,3,2,2,1};
	uint16_t beat_little_star[]={500,500,500,500,500,500,1000,500,500,500,500,500,500,1000,500,500,500,500,500,500,1000,500,500,500,500,500,500,1000,500,500,500,500,500,500,1000,500,500,500,500,500,500,1000};
  //Little Bee Song	
  uint8_t  note_little_bee[]={5,3,3,4,2,2,1,2,3,4,5,5,5,5,3,3,4,2,2,1,3,5,5,3,2,2,2,2,2,3,4,3,3,3,3,3,4,5,5,3,3,4,2,2,1,3,5,5,1};	
	uint16_t beat_little_bee[]={250,250,500,250,250,500,250,250,250,250,250,250,500,250,250,500,250,250,500,250,250,250,250,1000,250,250,250,250,250,250,500,250,250,250,250,250,250,500,250,250,500,250,250,500,250,250,250,250,1000};	
	//Sea Laugh
	uint8_t  note_sea_laugh[]={6+7,5+7,3+7,2+7,  1+7,  3+7,2+7,1+7,6,  5,  5,6,5,6,  1+7,2+7,3+7,5+7,\
		6+7,5+7,3+7,2+7,1+7,  2+7,  6+7,6+7,5+7,3+7,2+7,  1+7,  3+7,2+7,1+7,6,  5,\
		5,6,5,6, 1+7,2+7,3+7,5+7, 6+7,5+7,3+7,2+7,1+7,  1+7  };	
		
uint16_t beat_sea_laugh[ ]={750,250,500,500,  2000,  750,250,500,500,  2000,  750,250,500,500,  750,250,500,500,\
		750,250,250,250,500,  2000,  500, 250,250,500,500,  2000,  750,250,500,500,  2000, \
		750,250,500,500,  750,250,500,500,  750,250,250,250,500,  2000};	


	uint32_t i, tone, beat, soundStop;
	
	//soundStop=beatTime*1.3;					// no sound delay 
	soundStop=beatTime;	
	EnablePWM();
		
	switch(song_num)
	{
		case Melody_sea_laugh:
			printf("play sea_laugh\n\r");
		
			for(i=0; i<sizeof(note_sea_laugh); i++)
			{
				tone=note_sea_laugh[i];
				tone+=7;
				SelectTone(tone);
				beat = beat_sea_laugh[i];
				TIM2Delay(beat);
				DisablePWM();
				TIM2Delay(soundStop);
				if(current_song_num != Melody_sea_laugh)
					break;
				EnablePWM();
			}
		
			break;
		
		case Melody_happy_song:
			printf("play happy song\n\r");
		
			for(i=0; i<sizeof(note_happy_song); i++)
			{
				tone=note_happy_song[i];
				tone+=7;
				SelectTone(tone);
				beat =beat_happy_song[i];
				TIM2Delay(beat);
				DisablePWM();
				TIM2Delay(soundStop);
				if(current_song_num != Melody_happy_song)
					break;
				EnablePWM();
			}
			break;
		case Melody_little_star:
			printf("play little_star\n\r");
		
			for(i=0; i<sizeof(note_little_star); i++)
			{
				tone=note_little_star[i];
				tone+=7;
				SelectTone(tone);
				beat =beat_little_star[i];
				TIM2Delay(beat);
				DisablePWM();
				TIM2Delay(soundStop);
				if(current_song_num != Melody_little_star)
					break;
				EnablePWM();
			}
		
			break;
		case Melody_little_bee:
			printf("play little_bee\n\r");
		
			for(i=0; i<sizeof(note_little_bee); i++)
			{
				tone=note_little_bee[i];
				tone+=7;
				SelectTone(tone);
				beat =beat_little_bee[i];
				TIM2Delay(beat);
				DisablePWM();
				TIM2Delay(soundStop);
				if(current_song_num != Melody_little_bee)
					break;
				EnablePWM();
			}
			break;
		default:
			break;
		
	}
	DisablePWM();

}	


/*--------------------------------------------------------------------------------*/
// The processor clock is initialized by CMSIS startup + system file
/*--------------------------------------------------------------------------------*/
void melody_main (void) {        // User application starts here, renamed on 20181115
	
	ConfigTimer2();
	
	Config_PB4_TIM3_PWM();
	
	ConfigEXTIPA01();
	Config_PB3PB5();
}
